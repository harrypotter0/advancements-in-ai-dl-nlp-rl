package com.marauders.vibhuagarwal.elclassico;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView madridGoals,barcaGoals,mdShot,mdTargt,mdFoul,mdCorn,mdOff,barShot,barTargt,barFoul,barCorn,barOff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        madridGoals = (TextView)findViewById(R.id.mad_goals);
        barcaGoals = (TextView)findViewById(R.id.bar_goals);
        mdShot = (TextView)findViewById(R.id.madrid_shots);
        mdTargt = (TextView)findViewById(R.id.madrid_target);
        mdFoul = (TextView)findViewById(R.id.madrid_fouls);
        mdCorn = (TextView)findViewById(R.id.madrid_corners);
        mdOff = (TextView)findViewById(R.id.madrid_offsides);
        barShot = (TextView)findViewById(R.id.barca_shots);
        barTargt = (TextView)findViewById(R.id.barca_target);
        barFoul = (TextView)findViewById(R.id.barca_fouls);
        barCorn = (TextView)findViewById(R.id.barca_corners);
        barOff = (TextView)findViewById(R.id.barca_offsides);
    }
    public void madridGoal(View view)
    {
        madridGoals.setText((""+(Integer.parseInt(madridGoals.getText().toString())+1)));
    }
    public void madridShot(View view)
    {
        mdShot.setText((""+(Integer.parseInt(mdShot.getText().toString())+1)));
    }
    public void madridTarget(View view)
    {
        mdTargt.setText((""+(Integer.parseInt(mdTargt.getText().toString())+1)));
    }
    public void madridFoul(View view)
    {
        mdFoul.setText((""+(Integer.parseInt(mdFoul.getText().toString())+1)));
    }
    public void madridCorner(View view)
    {
        mdCorn.setText((""+(Integer.parseInt(mdCorn.getText().toString())+1)));
    }
    public void madridOffside(View view)
    {
        mdOff.setText((""+(Integer.parseInt(mdOff.getText().toString())+1)));
    }
    public void barcaGoal(View view)
    {
        barcaGoals.setText((""+(Integer.parseInt(barcaGoals.getText().toString())+1)));
    }
    public void barcaShot(View view)
    {
        barShot.setText((""+(Integer.parseInt(barShot.getText().toString())+1)));
    }
    public void barcaTarget(View view)
    {
        barTargt.setText((""+(Integer.parseInt(barTargt.getText().toString())+1)));
    }
    public void barcaFoul(View view)
    {
        barFoul.setText((""+(Integer.parseInt(barFoul.getText().toString())+1)));
    }
    public void barcaCorner(View view)
    {
        barCorn.setText((""+(Integer.parseInt(barCorn.getText().toString())+1)));
    }
    public void barcaOffside(View view)
    {
        barOff.setText((""+(Integer.parseInt(barOff.getText().toString())+1)));
    }
    public void resetClicked(View view)
    {
        madridGoals.setText("0");
        barcaGoals.setText("0");
        mdShot.setText("0");
        mdTargt.setText("0");
        mdFoul.setText("0");
        mdCorn.setText("0");
        mdOff.setText("0");
        barShot.setText("0");
        barTargt.setText("0");
        barFoul.setText("0");
        barCorn.setText("0");
        barOff.setText("0");
    }
}
